<?php

namespace App\Exceptions;
// use App\Exceptions\JwtHandlerException;


use Exception;

class JwtHandlerException extends Exception
{
    //
}
