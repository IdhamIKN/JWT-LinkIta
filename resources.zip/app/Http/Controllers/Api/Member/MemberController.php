<?php

namespace App\Http\Controllers\Api\Member;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use meter;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Http\Controllers\Api\LinkIta\GenerateController;
use App\Models\Member;
use App\Models\User;

class MemberController extends Controller
{
    public function topUp(Request $request)
    {
        $Generate = new GenerateController;
        $tiket = $Generate->idTransaksi();

        $user = auth()->guard('api')->user()->id;

        // Set validation rules
        $validator = Validator::make($request->all(), [
            'nominal' => 'required'
        ], [
            'nominal.required' => 'Nominal harus diisi.'
        ]);

        // If validation fails
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }
        // Create member
        $member = Member::create([
            'debit'  => $request->nominal,
            'status'  => '1',
            'id_user' => $user,
            'tiket' => 'T-' . $tiket
        ]);

        // Return JSON response if member is created
        if ($member) {
            return response()->json([
                'SUCCES' => true,
                'TIKET' => 'T-' . $tiket,
                'MEMBER ID' => $user,
                'NOMINAL'  => $request->nominal,
                'STATUS'  => 'SEDANG DIPROSES'
            ], 201);
        }

        // Return JSON response if the insertion process failed
        return response()->json([
            'success' => false
        ], 409);
    }

    public function verifytopUp(Request $request)
    {
        $Generate = new GenerateController;
        $tiket = $Generate->idTransaksi();

        // Set validation rules
        $validator = Validator::make($request->all(), [
            'nominal' => 'required',
            'tiket' => 'required'
        ], [
            'nominal.required' => 'Nominal harus diisi.',
            'tiket.required' => 'Id User harus diisi.'
        ]);

        // If validation fails
        if ($validator->fails()) {
            return response()->json($validator->errors(), 400);
        }

        // Check if the ticket exists in the database
        $member = Member::where('tiket', $request->tiket)->first();

        // If the ticket does not exist
        if (!$member) {
            return response()->json([
                'success' => false,
                'message' => 'Tiket tidak valid.'
            ], 404);
        }

        // Update member
        $member->kredit = $request->nominal;
        $member->status = '2';
        $member->tiket = 'S-' . $tiket;
        $member->save();

        // Return JSON response if member is updated successfully
        return response()->json([
            'success' => true,
            'MEMBER ID' => $request->tiket,
            'NOMINAL'  => $request->nominal,
            'STATUS'  => 'TRANSAKSI SUKSES'
        ], 200);
    }
}
