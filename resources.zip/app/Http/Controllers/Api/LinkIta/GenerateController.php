<?php

namespace App\Http\Controllers\Api\LinkIta;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Exception;
use App\Helpers\Helper;
use Illuminate\Support\Carbon;
use App\Constants\LKMethod;
use App\Constants\LKConstant;
use App\Models\lk_log;



class GenerateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // Ambil Jwt Token User
    public function getJwtToken()
    {
        $user = auth()->guard('api')->user();

        if ($user) {
            return $user->jwt;
        } else {
            // throw an exception or return an error response
            throw new Exception('Gagal');
        }
    }

    // Ambil Waktu
    public function time()
    {
        $time = Carbon::now()->toDateTimeString();
        return $time;
    }

    // Generate Signature
    public function generateSignature($clientKey, $method, $kodeProduk, $waktu, $idPelanggan, $idMember, $ref1)
    {
        $stringToHash = $clientKey . "|" . $method . "|" . $kodeProduk . "|" . $waktu . "|" . $idPelanggan . "|" . $idMember . "|" . $ref1;
        $signature = md5($stringToHash);

        return $signature;
    }

    // Generate Reff
    public function generateRef1()
    {
        $dateTime = new \DateTime();
        $currentDateTime = $dateTime->format('mdHis');
        $randomNumber = mt_rand(100, 999);

        $ref1 = $currentDateTime . $randomNumber;

        return $ref1;
    }


    // Create Lk_log
    public function createLog($content, $method)
    {
        $log = new lk_log;
        $log->customer_id = $content->id_pelanggan ?? 0;
        $log->nama = $content->nama_pelanggan ?? 0;
        $log->method = $method;
        $log->id_pay = $content->id_transaksi_pay ?? 0;
        $log->id_inq = $content->id_transaksi_inq ?? 0;
        $log->nominal = $content->nominal ?? 0;
        $log->status = $content->status ?? 0;
        $log->ket =  $content->keterangan ?? 0;
        $log->content = json_encode($content);
        $log->save();

        return $log;
    }


    ////////////////////////////////
    // Generate Reff
    public function idTransaksi()
    {
        $dateTime = new \DateTime();
        $currentDateTime = $dateTime->format('sid');
        $randomNumber = mt_rand(100, 999);

        $ref1 = $currentDateTime . $randomNumber;

        return $ref1;
    }
    public function unik()
    {
        $dateTime = new \DateTime();
        $currentDateTime = $dateTime->format('s');

        $ref1 = $currentDateTime;

        return $ref1;
    }
}
